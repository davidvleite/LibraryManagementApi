﻿using LibraryManagementApi.Model;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementApi.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<AutorModel> Autores { get; set; }
        public DbSet<LivroModel> Livros { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

}
}
