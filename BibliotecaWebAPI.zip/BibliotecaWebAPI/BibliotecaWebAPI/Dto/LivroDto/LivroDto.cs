﻿using LibraryManagementApi.Dto.VinculoDto;
using LibraryManagementApi.Model;

namespace LibraryManagementApi.Dto.LivroDto
{
    public class LivroDto
    {
        public string Titulo { get; set; }
        public VinculoAutorLivroDto Autor { get; set; }

    }
}