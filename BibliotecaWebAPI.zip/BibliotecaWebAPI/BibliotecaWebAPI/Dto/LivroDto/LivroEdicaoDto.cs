﻿using LibraryManagementApi.Dto.VinculoDto;
using LibraryManagementApi.Model;

namespace LibraryManagementApi.Dto.LivroDto
{
    public class LivroEdicaoDto
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public VinculoAutorLivroDto Autor { get; set; }

    }
}
