﻿namespace LibraryManagementApi.Dto.AutorDto
{
    public class AutorDto
    {
        public string Nome { get; set; }
        public string Sobrenome { get; set; }

    }
}
