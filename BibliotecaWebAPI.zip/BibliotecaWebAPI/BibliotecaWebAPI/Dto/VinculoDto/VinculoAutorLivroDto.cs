﻿namespace LibraryManagementApi.Dto.VinculoDto
{
    public class VinculoAutorLivroDto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }

    }
}
