﻿using LibraryManagementApi.Dto.AutorDto;
using LibraryManagementApi.Model;

namespace LibraryManagementApi.Services.Autor
{
    public interface IAutorService
    {
        Task<ResponseModel<List<AutorModel>>> ListarAutores();
        Task<ResponseModel<AutorModel>> BuscarAutorPorId(int idautor);
        Task<ResponseModel<AutorModel>> BuscarAutorPorIdDoLivro(int idLivro);
        Task<ResponseModel<List<AutorModel>>> CriarAutor(AutorDto autorDto);
        Task<ResponseModel<List<AutorModel>>> EditarAutor(AutorEdicaoDto autorEdicaoDto);
        Task<ResponseModel<List<AutorModel>>> ExcluirAutor(int idAutor);
    }
}
