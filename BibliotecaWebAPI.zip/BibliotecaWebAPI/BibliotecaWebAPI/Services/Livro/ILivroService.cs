﻿using LibraryManagementApi.Dto.LivroDto;
using LibraryManagementApi.Model;

namespace LibraryManagementApi.Services.Livro
{
    public interface ILivroService
    {
        Task<ResponseModel<List<LivroModel>>> ListarLivros();
        Task<ResponseModel<LivroModel>> BuscarLivrosPorId(int idLivro);
        Task<ResponseModel<List<LivroModel>>> BuscarLivroPorIdDoAutor(int idAutor);
        Task<ResponseModel<List<LivroModel>>> Criarlivro(LivroDto livroDto);
        Task<ResponseModel<List<LivroModel>>> EditarLivro(LivroEdicaoDto livroEdicaoDto);
        Task<ResponseModel<List<LivroModel>>> ExcluirLivro(int idLivro);
    }
}
