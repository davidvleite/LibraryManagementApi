﻿using LibraryManagementApi.Dto.AutorDto;
using LibraryManagementApi.Dto.LivroDto;
using LibraryManagementApi.Model;
using LibraryManagementApi.Services.Autor;
using LibraryManagementApi.Services.Livro;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LivroController : ControllerBase
    {

        private readonly ILivroService _livroService;
        public LivroController(ILivroService livroService)
        {
            _livroService = livroService;
        }

        [HttpGet("ListarLivros")]
        public async Task<ActionResult<ResponseModel<List<LivroModel>>>> ListarLivros()
        {
            var livros = await _livroService.ListarLivros();
            return Ok(livros);
        }

        [HttpGet("BuscarLivroPorId/{idLivro}")]
        public async Task<ActionResult<ResponseModel<LivroModel>>> BuscarLivroPorId(int idLivro)
        {
            var livro = await _livroService.BuscarLivrosPorId(idLivro);
            return Ok(livro);
        }

        [HttpGet("BuscarAutorPorIdDoLivro/{idLivro}")]
        public async Task<ActionResult<ResponseModel<LivroModel>>> BuscarLivroPorIdDoAutor(int idAutor)
        {
            var livro = await _livroService.BuscarLivroPorIdDoAutor(idAutor);
            return Ok(livro);
        }

        [HttpPost("CriarLivro")]
        public async Task<ActionResult<ResponseModel<List<LivroModel>>>> CriarLivro(LivroDto livroDto)
        {
            var livro = await _livroService.Criarlivro(livroDto);
            return Ok(livro);
        }

        [HttpPut("EditarLivro")]
        public async Task<ActionResult<ResponseModel<List<LivroModel>>>> EditarLivro(LivroEdicaoDto livroEdicaoDto)
        {
            var livro = await _livroService.EditarLivro(livroEdicaoDto);
            return Ok(livro);
        }

        [HttpDelete("ExcluirLivro")]
        public async Task<ActionResult<ResponseModel<List<LivroModel>>>> ExcluirAutor(int idLivro)
        {
            var livro = await _livroService.ExcluirLivro(idLivro);
            return Ok(livro);
        }

    }
}
